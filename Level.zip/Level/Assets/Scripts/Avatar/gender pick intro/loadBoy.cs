﻿using UnityEngine;
using System.Collections;
using UnityEngine.SceneManagement;

public class loadBoy : MonoBehaviour {

	public void StartGame() {
		SceneManager.LoadScene ("male_character_customization");
	}
		
	// Use this for initialization
	void Start () {
	
	}
	
	// Update is called once per frame
	void Update () {
	
	}
}
